document.addEventListener('DOMContentLoaded', function () {
    const registerForm = document.getElementById('registerForm');
    const roleSelect = document.getElementById('registerRole');
    const professionGroup = document.getElementById('professionGroup');
    const phoneInput = document.getElementById('registerPhone');

    if (roleSelect && professionGroup) {
        roleSelect.addEventListener('change', function () {
            if (this.value === 'technician') {
                professionGroup.style.display = 'block';
            } else {
                professionGroup.style.display = 'none';
            }
        });
    }

    if (phoneInput) {
        phoneInput.addEventListener('input', function () {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const name = document.getElementById('registerName').value;
            const email = document.getElementById('registerEmail').value;
            const phone = document.getElementById('registerPhone').value;
            const password = document.getElementById('registerPassword').value;
            const role = document.getElementById('registerRole').value;
            const profession = document.getElementById('registerProfession') ? document.getElementById('registerProfession').value : '';
            const btn = registerForm.querySelector('button[type="submit"]');

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإنشاء...';

            try {
                const { data, error } = await supabaseClient.auth.signUp({
                    email: email,
                    password: password
                });

                console.log('SignUp result:', data, 'SignUp error:', error);

                if (error) {
                    console.log('SignUp error:', error);
                    if (error.message.includes('already registered')) {
                        alert('هذا البريد الإلكتروني مسجل بالفعل');
                    } else {
                        alert('حدث خطأ: ' + error.message);
                    }
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-user-plus"></i> إنشاء الحساب';
                    return;
                }

                console.log('User created with ID:', data.user.id);

                const userData = {
                    id: data.user.id,
                    name: name,
                    email: email,
                    phone: phone,
                    role: role,
                    profession: profession,
                    status: role === 'technician' ? 'pending' : 'active'
                };

                const { data: insertData, error: insertError } = await supabaseClient
                    .from('users')
                    .insert([userData])
                    .select();

                console.log('Insert result:', insertData, 'Insert error:', insertError);

                if (insertError) {
                    if (insertError.code === '409' || insertError.message.includes('duplicate')) {
                        alert('هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول.');
                        window.location.href = 'login.html';
                        return;
                    }
                    alert('خطأ في حفظ البيانات: ' + insertError.message);
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-user-plus"></i> إنشاء الحساب';
                    return;
                }

                if (role === 'technician') {
                    await saveAdminNotification(
                        'فني جديد بانتظار التفعيل',
                        `قام الفني ${name} بإنشاء حساب جديد بانتظار مراجعة الإدارة`,
                        'fas fa-user-plus',
                        'orange',
                        'admin_user_pending',
                        data.user.id
                    );
                    await supabaseClient.auth.signOut();
                    alert('تم إنشاء حسابك بنجاح!\nحسابك قيد الانتظار وسيتم تفعيله من قبل الإدارة قريباً.');
                    window.location.href = 'login.html';
                } else {
                    setCurrentUserCache(userData);
                    window.location.href = 'customer-dashboard.html';
                }
            } catch (err) {
                alert('حدث خطأ، حاول مرة أخرى');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-user-plus"></i> إنشاء الحساب';
            }
        });
    }
});
