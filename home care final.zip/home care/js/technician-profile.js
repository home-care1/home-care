document.addEventListener('DOMContentLoaded', async function() {
    const currentUser = await ensureCurrentUser();
    if (!currentUser || currentUser.role !== 'technician') {
        window.location.href = 'login.html';
        return;
    }

    loadProfile();

    loadNotifDropdown();
    setInterval(loadNotifDropdown, 15000);

    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const btn = profileForm.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
            
            const name = document.getElementById('profileNameInput').value;
            const phone = document.getElementById('profilePhoneInput').value;
            const email = document.getElementById('profileEmailInput').value;
            const profession = document.getElementById('profileProfessionInput').value;
            const bio = document.getElementById('profileBioTextarea').value;

            const updateData = {
                name: name,
                phone: phone,
                email: email,
                bio: bio
            };
            
            if (profession) {
                updateData.profession = profession;
            }

            await updateUser(currentUser.id, updateData);

            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> حفظ التغييرات';
            
            showAlert('تم حفظ التغييرات بنجاح', 'success');
            
            loadProfile();
        });
    }

    async function loadProfile() {
        const user = await findUserById(currentUser.id);
        
        if (user) {
            document.getElementById('profileName').textContent = user.name || '---';
            document.getElementById('profileRole').textContent = 'فني صيانة';
            document.getElementById('profileEmail').textContent = user.email || '---';

            document.getElementById('profileNameInput').value = user.name || '';
            document.getElementById('profilePhoneInput').value = user.phone || '';
            document.getElementById('profileEmailInput').value = user.email || '';
            document.getElementById('profileProfessionInput').value = user.profession || '';
            document.getElementById('profileBioTextarea').value = user.bio || '';
        }
    }

    function showAlert(message, type) {
        const alert = document.getElementById('profileAlert');
        if (alert) {
            alert.textContent = message;
            alert.className = `alert alert-${type} show`;
            
            setTimeout(() => {
                alert.classList.remove('show');
            }, 3000);
        }
    }
});
